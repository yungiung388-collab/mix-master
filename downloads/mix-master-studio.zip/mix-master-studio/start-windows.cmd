@echo off
cd /d "%~dp0"
node --version
if errorlevel 1 (
echo Please install Node.js 24.5 or newer.
pause
exit /b 1
)
npm start
pause
